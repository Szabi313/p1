from tryClass import MyClass

iClass = MyClass('Valaki')
#iClass.getName()

def main():
	iClass.getName()
#	print(bin(int('1101', 2) & int('0010',2))
		
if __name__ == '__main__':
	main()