class MyClass:
	def __init__(self, name):
		self.name = name
		
	def getName(self):
		print(self.name)
		
def main():
		print('tryClass')
		
if __name__ == '__main__':
	main()